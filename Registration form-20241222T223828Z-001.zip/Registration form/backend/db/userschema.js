const mongoose = require('mongoose');
mongoose.connect("mongodb://localhost:27017/RegistrationApp");
const Schema = mongoose.Schema;

// Create a new Schema for the User model
const userSchema = new mongoose.Schema({
    name:String,
    Email:String,
    Password:String,
    Mobileno:String,
    gender:String,
    Dob:String,
    About:String
  })

// Create a Mongoose model for the user schema
const User = mongoose.model('User', userSchema);

module.exports = User;
