const express = require('express');
const User = require('./db/userschema');
const cors = require('cors');

const app = express()
app.use(express.json())
app.use(cors());


app.post('/register',async(req,res)=>{
    const {name,Email,Password,Mobileno,gender,Dob,About} = req.body;
    const newUser = new User({name,Email,Password,Mobileno,gender,Dob,About});
    try {
        // Save the new user to the database
        await newUser.save();
        res.status(201).json({
            message: 'User registered successfully',
            success: true,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: 'Error registering user',
            success: false,
            error: error.message,
        });
    }
});


app.get('/getdata',async(req,res) => {
    try {
        const users = await User.find();  
        res.status(200).json({
            users: users, 
            success: true,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: 'Error fetching users',
            success: false,
            error: error.message,
        });
    }
});



app.listen(3000,()=>{
    console.log("Server is up!")
})